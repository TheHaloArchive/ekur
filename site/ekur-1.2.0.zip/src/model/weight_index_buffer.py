# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright © 2026 The Halo Archive
from io import BufferedReader

from ..exceptions import IncorrectStrideValue
from .vectors import ByteVector4, ShortVector4

__all__ = ["WeightIndexBuffer"]


class WeightIndexBuffer:
    def __init__(self) -> None:
        self.stride: int = -1
        self.count: int = 0
        self.indices: list[ByteVector4 | ShortVector4] = []

    def read(self, reader: BufferedReader) -> None:
        self.stride = int.from_bytes(reader.read(1), "little", signed=True)
        if self.stride % 2 != 0:
            raise IncorrectStrideValue("WeightIndex buffer stride was not a multiple of 2!")

        self.count = int.from_bytes(reader.read(4), "little")
        for _ in range(self.count):
            if self.stride == 4:
                vector = ByteVector4()
                vector.read(reader)
                self.indices.append(vector)
            if self.stride == 8:
                vector = ShortVector4()
                vector.read(reader)
                self.indices.append(vector)
